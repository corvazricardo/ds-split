
def preprocessSentence(sentence):
    """
        preprocess token by removing hyphen and dot
    :param sentence: the string to be preprocessed
    :return: a sentence preprocessed
    """
    try:
        if isinstance(sentence, str) and sentence is not None:
            preproc_sentence = sentence.replace("-", "").replace(".", "")
    except:
        print("Invalid sentence not preprocessed:{}".format(sentence))
        preproc_sentence = None
    return preproc_sentence



