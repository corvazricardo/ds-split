import wordninja

"""
Word splitter using wordninja library
See reference: https://pypi.org/project/wordninja/
"""

def splitConcatTokens(concattokens):
    """
    Split concatenated tokens hidden in a sentence
    :param concattokens: the string sentence with concatenated tokens
    :return: a list of tokens split
    """
    try:
        lexicon_splits = getLexicon()
        if isinstance(concattokens, str) and concattokens is not None:
            tokens = wordninja.split(concattokens)
            tokens = tuneSentence(tokens,lexicon_splits)
    except:
        print("Invalid value:{}".format(concattokens))
        tokens = None
    return tokens


def tuneSentence(sentence, lexicon_splits):
    """
    Tune a sentence with correct split of restaurant/venue names if they are part of the lexicon created
    :param param sentence: the predicted split of a sentence as a list
    :param lexicon_splits: the dictionary with names in lexicon
    :return: the tuned sentence with the correct splits of restaurant/names if incorreclty splitted
    """
    name_start = None
    name_end = None
    name_lexicon = None
    is_included = False
    tuned_sentence = []

    is_included, name_lexicon, name_start, name_end = isNameIncluded(sentence, lexicon_splits)
    if is_included and name_lexicon is not None and name_start is not None and name_end is not None:
        tuned_sentence = [sentence[i] for i in range(0, len(sentence)) if i <= name_start or i > name_end]
        tuned_sentence[name_start] = name_lexicon
    else:
        tuned_sentence = sentence
    return tuned_sentence

def isNameIncluded(sentence,lexicon_splits):
    """
    Detecting any potential restaurant/venue name in predicted split
    :param sentence: the predicted split of a sentence as a list
    :param lexicon_splits: the dictionary with names in lexicon
    :return: a flag saying if sentence contains a name of the lexicon, the proper split of a restaurant name,
    its start and end index in the sentence list
    """
    name_start = None
    name_end = None
    name_lexicon = None
    is_included = False
    is_found = False
    for i in sentence:
        for name in lexicon_splits.keys():
            if name.lower().startswith(i):
                start = sentence.index(i)
                tmp_name_split = lexicon_splits[name]
                is_included = all(elem in sentence for elem in tmp_name_split)
                if is_included and not is_found:
                    name_start = sentence.index(i)
                    name_end = start + len(tmp_name_split) -1
                    name_lexicon = name
                    is_found = True
    return is_included,name_lexicon,name_start,name_end

def getLexicon():
    """
    Create and return the lexicon that tunes the splitter
    :return:  a lexicon with the splits made by splitter for each of the rare names discovered in dataset
    """
    lexicon_names = ['aromi', 'cocum', 'alimentum']
    lexicon_splits = {name: wordninja.split(name) for name in lexicon_names}
    return lexicon_splits