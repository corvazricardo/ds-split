from flask import Flask

import argparse
import logging
import os


class Demo(Flask):

    def __init__(self, *args, **kwargs):
        super(Demo, self).__init__(*args, **kwargs)


def argument_parser():
    """
    Define settings required for application
    :return: settings desired for the app to run
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('-address',
                        default=os.environ.get('ADDRESS', '0.0.0.0'),
                        type=str,
                        help='App address')
    parser.add_argument('-port',
                        default=os.environ.get('PORT', 8000),
                        type=int,
                        help='App port')
    parser.add_argument('-debug',
                        action='store_true',
                        help='Debug mode for Flask')
    parser.add_argument("-c", "--config", dest="config_json",
                        default='config.json',
                        help='The filename comprising settings for app')
    args = parser.parse_args()

    return args


def main():
    """
    The main method to fetch settings for running the app
    :return: settings from user to start running the app as desired
    """

    logging.basicConfig(
        format="%(asctime)s.%(msecs).3d %(levelname)s %(module)s - %(funcName)s: %(message)s",
    )
    args = argument_parser()

    return args


# Starting MeetupPredictor app
basedir = os.path.abspath(os.path.dirname(__file__))
app = Demo(__name__)

# Linking routes to app
from restservice import routes
