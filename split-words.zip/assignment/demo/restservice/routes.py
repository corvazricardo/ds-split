from restservice.Demo import app

from flask import redirect, url_for, render_template, request
import logging

from utils.Utils import *
from splitter.WordNinjaSplitter import *



@app.before_first_request
def initialize():
    """
    initialize the REST service
    """
    app.logger.setLevel(logging.INFO)
    app.logger.info("Initialized split-prediction")
    return


@app.route('/', methods=['GET', 'POST'])
def root():
    """
    redirect to home page once app has been initialized
    :return:
    """
    return redirect(url_for('home'))


@app.route('/api/split-prediction/home', methods=['GET', 'POST'])
def home():
    """
    the home route of the REST service
    :return: home template
    """

    return render_template("home.html", title='Home')


def shutdown_server():
    """
    shutdown the REST service
    """
    func = request.environ.get('werkzeug.server.shutdown')
    if func is None:
        raise RuntimeError('Not running with the Werkzeug Server')
    func()


@app.route('/shutdown', methods=['GET'])
def shutdown():
    """
    the shutdown route of the REST service
    """
    shutdown_server()
    return 'Server shutting down...Done'

@app.route('/api/split-prediction/predict/', methods=['GET', 'POST'])
def predict():
    """
    the route to compute the prediction for the REST service
    :return: home template
    """
    #get Params from request
    sentence = request.args.get('sentence')

    preproc_sentence = preprocessSentence(sentence)

    split = splitConcatTokens(preproc_sentence)

    output_response = " ".join(split)

    return redirect(url_for('prediction', output_response=output_response))

@app.route('/api/split-prediction/prediction/<output_response>/', methods=['GET', 'POST'])
def prediction(output_response):
    """
    the end-point of the REST service
    :return: prediction as an html template
    """
    split_sentence = output_response


    return render_template("prediction_base.html", title='Prediction', split_sentence=split_sentence )
