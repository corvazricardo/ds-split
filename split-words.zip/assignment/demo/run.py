from restservice.Demo import app, main


if __name__ == "__main__":
    args = main()
    app.run(host=args.address, port=args.port, debug=args.debug)


