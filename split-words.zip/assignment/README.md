
## Concatenated Words Split application
### Python/Flask application

Effort to build a splitting incorrectly concatenated words

The app folder contains a flask app, which can be run with ```docker run -p 8000:8000 demo-app``` once located under the root folder.
The requirements.txt indicates depedencies required for this app

Project structure:
```
.
├── notebooks
	  └──Main Solution.ipynb 
	  |──resources
    		├── data
    		└──  imgs


├── demo
    ├── restservice
    ├── run.py
    └── ...
├── requirements.txt
├── Dockerfile
├── README.md
```


The notebooks folder contains 1 notebook which explain the solution developed. A good start point is ```Main Solution.ipynb``` which provides an overall explanation of the solution created. After that it is recommended to run the demo created.